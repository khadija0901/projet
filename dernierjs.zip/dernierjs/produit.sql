-- MySQL dump 10.13  Distrib 5.7.37, for Linux (x86_64)
--
-- Host: localhost    Database: produit
-- ------------------------------------------------------
-- Server version	5.7.37-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `detail`
--

DROP TABLE IF EXISTS `detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) DEFAULT NULL,
  `prix` float DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detail`
--

LOCK TABLES `detail` WRITE;
/*!40000 ALTER TABLE `detail` DISABLE KEYS */;
INSERT INTO `detail` VALUES (1,'Beignet Coco',200,'Grignoter','IMG_Cuisine/Grignoter/beignet coco.jpg'),(2,'Beignet nox',100,'Grignoter','IMG_Cuisine/Grignoter/beignet nox.jpeg'),(3,'Fataya Senegalaise',200,'Grignoter','IMG_Cuisine/Grignoter/fataya à la senegalaise.jpg'),(4,'Viande au frite',1500,'Grignoter','IMG_Cuisine/Grignoter/5.jpg'),(5,'Thiéré Tamkharit',2000,'Diner','IMG_Cuisine/Plat diner/thiéré tamkharit.jpg'),(6,'Vermille Guinar',1500,'Diner','IMG_Cuisine/Plat diner/vermiselle guinar.jpg'),(7,'Salate Ordinaire',3000,'Diner','IMG_Cuisine/Plat diner/salate ordinaire.jpg'),(8,'Sauce Guinar',2500,'Diner','IMG_Cuisine/Plat diner/firir guinar.jpg'),(9,'Diner en famille',15000,'Diner','IMG_Cuisine/Plat diner/couscous guinar dessert.jpg'),(10,'Thiébou Dieune',1500,'Repas','IMG_Cuisine/Plat repas/thiébou dieune.jpg'),(11,'Thiébou Yapp',2500,'Repas','IMG_Cuisine/Plat repas/thiébou yapp.jpg'),(12,'Yassa Guinar',2500,'Repas','IMG_Cuisine/Plat repas/yassa guinar.jpg'),(13,'Yassa bou jaune',1500,'Repas','IMG_Cuisine/Plat repas/yassa safron.jpg'),(14,'Mbaffé',1500,'Repas','IMG_Cuisine/Plat repas/mnaffé.jpg'),(15,'Damada yapp',2500,'Repas','IMG_Cuisine/Plat repas/damada yapp.jpg'),(16,'Cest bon',2000,'Repas','IMG_Cuisine/Plat repas/cest bon.jpg'),(17,'Thiou',1500,'Repas','IMG_Cuisine/Plat repas/thiou.jpg'),(18,'Dibi Yapp',4000,'Invitation','IMG_Cuisine/Plat resto/dibi.jpg'),(19,'Diner avec Collegue',15000,'Invitation','IMG_Cuisine/Plat resto/diner avec collegue.jpg'),(20,'Diner en famille',20000,'Invitation','IMG_Cuisine/Plat resto/diner en famille.jpg'),(21,'Paella',5000,'Invitation','IMG_Cuisine/Plat resto/Paella.jpg'),(22,'Jus bouille',1500,'Jus','IMG_Cuisine/type de jus/jus bouille.jpg'),(23,'Jus bouille avec carossole',1500,'Jus','IMG_Cuisine/type de jus/jus bouye.jpg'),(24,'Bissap blanc',2000,'Jus','IMG_Cuisine/type de jus/jus de bissap.jpg'),(25,'Jus de Bissap',2000,'Jus','IMG_Cuisine/type de jus/jus de bissap red.jpg'),(26,'Bissap avec menthe',1500,'Jus','IMG_Cuisine/type de jus/jus de bissap rouge.jpg'),(27,'Jus de Citron',1000,'Jus','IMG_Cuisine/type de jus/jus de citron.jpg'),(28,'Jus de Coco',1000,'Jus','IMG_Cuisine/type de jus/jus de coco.jpg');
/*!40000 ALTER TABLE `detail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-25 17:26:09
