        function afficher(){
           resto.style= "border: solid blue";
        }
        function deselectionner(){
           resto.style= "border: none";
        }
         function bouton(){
           window.location.href= "test2.html";
        }

	function ajout(){
            let nom = document.getElementById("nom").textContent;
	    let prix = document.getElementById("prix").textContent;
            let type = document.getElementById("type").attributes[1].value;
	    let image = document.getElementById("image").attributes[1].value;
	    let data = [nom,prix,type,image];
	    data.ajouterArticle(nom, prix, type, image);
            let tableau = document.getElementById("panier");

            document.getElementById("prixTotal").innerHTML = data.getPrixPanier();

        }


 	function suppression(code){
                let data;
                let tableau = document.getElementById("panier");
                document.getElementById("prixTotal").innerHTML = data.getPrixPanier();
        }

  
