
function ajoutpanier (nom, prix)
{
    this.nom = nom;
    this.prix = prix;
    {
        let resultat = this.prixArticle;
        return resultat;
    }
    this.getCode = function() 
    {
        return this.codeArticle;
    }
}


function panier()
{
    this.liste = [];
    this.ajouterArticle = function(nom, prix, )
    { 
        let index = this.getArticle(nom);
        if (index == -1) this.liste.push(new ajoutanier(nom, prix));
        else this.liste[index].ajouterQte(qte);
    }
    this.getPrixPanier = function()
    {
        let total = 0;
        for(let i = 0 ; i < this.liste.length ; i++)
            total += this.liste[i].getPrixLigne();
        return total;
    }
    this.getArticle = function(code)
    {
        for(let i = 0 ; i <this.liste.length ; i++)
            if (nom == this.liste[i].getCode()) return i;
        return -1;
    }
    this.supprimerArticle = function(nom)
    {
        let index = this.getArticle(nom);
        if (index > -1) this.liste.splice(index, 1);
    }
}
