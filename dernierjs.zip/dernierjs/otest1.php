<?php
 // $query= intvall($_GET['query']);
  $conn= mysqli_connect("localhost", "dija", "Passer123/", "produit");

  if (!$conn){
    die('Could not connect: '/mysqli_error($conn));
  }
  $req1 ="select * from detail";

  $result =mysqli_query($conn, $req1);
  echo "<table>
  <tr> 
    <th>Nom </th>
    <th>Prix </th> 
    <th>Type </th>
    <th>Image</th>
    </tr>";
  while ($row = mysqli_fetch_assoc($result)){
    echo "<tr>";
      echo "<td>".$row["nom"]."</td>";
      echo "<td>".$row["prix"]."</td>";
      echo "<td>".$row["type"]."</td>";
      echo '<td><img src="./'.$row["image"].'" /></td>';
    echo "</tr>" ;
  }

  echo "</table>";
mysqli_close($conn);

?>







