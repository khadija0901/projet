window.onload function ajoutPanier(){
    bouton = ajout 

    button.onclick = function(){
        let nom = document.getElementById("nom").value ;
        let prix = document.getElementById("prix").value ;



    }

}








function choice(str){
  if (panier == ""){
    document.getElementById("myresto").innerHTML = "";
    return;
  }
  else{
    let reponse = new XMLHttpRequest();
    reponse.onreadystatechange = function(){
      if (){
        document.getElementById("myresto").innerHTML = this.responseText;
      }

    }
    reponse.open("GET", "test1.php");
    reponse.send();
    
  }
}sssssss
