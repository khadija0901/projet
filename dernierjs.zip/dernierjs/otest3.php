<?php
   // Les fonctions 
 
   function createPanier(){
        $conn= mysqli_connect("localhost", "khady", "Passer123/", "produit");
 
 
 
   //}
 //function ajouter($nom, $prix, $type, $image){
        //if (require("test14.php")){
           // $req = $access ->prepare ("insert into astuces (nom, prix, type, image) values ('$nom', $prix, '$type', '$image')");
           // $req-> execute (array($nom, $prix, $type, $image));
           // $req-> closeCursor();
        //}
    //}
 
	if(isset($_SESSION['panier'])){
 
		$_SESSION['panier'] = array();
		$_SESSION['panier']['nom'] = array();
		$_SESSION['panier']['prix'] = array();
		$_SESSION['panier']['type'] = array();
		$_SESSION['panier']['image'] = false;
		$select = $conn->query("SELECT id FROM detail");
		$data = $select->fetch(mysqli_connect);
		$_SESSION['panier']['id'] = $data->id;
 
	}
	return true;
 
}
 // la fonction d'ajout de produit au panier
function ajouterProduit($nom, $prix, $type, $image){
 
	if(createPanier() && !isVerrouille())
	{
 
		$positionProduit = array_search($nom, $_SESSION['panier']['nom']);
	}
	else{
		// c'estle message qui s'affiche
 
		echo 'Erreur!! Veuillez contacter l\'administrateur ajouterProduit';
	}
}
 
 
 
 
 
         if(!$erreur){
        //L'erreur pourrait venir de là 
 
        switch ($action){
 
          Case "ajout":
          //Appel à la fonction d'ajout
          ajouterProduit($nom,$prix,$type);
 
          break;
 
          Case "suppression":
 
          supprimerProduit($nom);
 
          break;
 
 
          Default:
 
          break;
 
        }
 
       }
      ?>
 
      <form method="post" action="">
        <table width="400">
          <tr>
            <td colspan="4">Votre panier</td>
          </tr>
          <tr>
            <td>Nom</td>
            <td>Prix</td>
            <td>Type</td>
            <td>Image</td>
          </tr>
 
      <?php
 
    if(isset($_GET['deletepanier']) && $_GET['deletepanier'] == true){
 
      supprimerPanier();
    }
 
    if(createPanier()){
 
 
      $nbProduit = count($_SESSION['panier']['nom']);
      if($nbProduit <= 0){
 
        echo "Oups votre panier est vide!!";
 
      }else{
        //j'ai des supçons sur cette "for" aussi
 
        for($i=0; $i<$nbProduit; $i++){
           ?>
           <tr>
 
            <td><br/><?php echo $_SESSION['panier']['nom'][$i]; ?></td>
            <td><br/><?php echo $_SESSION['panier']['prix']['$i']; ?></td>
            <td><br/><?php echo $_SESSION['panier']['id']."%"; ?></td>
            <td><br/><a href="panier.php?action=suppression&amp; l=<?php echo rawurlencode($_SESSION['panier']['nom'][$i]); ?>">X</a></td>
           </tr>
      <?php } ?>
 
 
           <tr>
 
             <td colspan="2"><br/>
              <p>Total: <?php echo montantGlobal(); ?></p>
              <p>Total avec id: <?php echo montantGlobalTva(); ?></p>
             </td>
 
           </tr>
 
           <tr>
 
             <td colspan="4">
              <input type="submit" value="rafraichir" />
              <input type="hidden" name="action" value="refresh"  />
              <a href="?deletepanier=true">Supprimer le panier</a>
             </td>
           </tr>
           <?php
 
 
      }
 
    }
      ?>
 
     </table>
 
      </form>
