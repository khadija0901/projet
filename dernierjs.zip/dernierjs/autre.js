window.onload function ajoutPanier(){
    bouton = ajout 

    button.onclick = function(){
        let nom = document.getElementById("nom").value ;
        let prix = document.getElementById("prix").value ;



    }

}

const prixTotalCalcul = [];
prixTotalCalcul.push(articleTotal);

const reducer = (accumulator, curr) => accumulator + curr;
const totalPrix = prixTotalCalcul.reduce(reducer);

let htmlPrix = document.querySelector("#totalPrice");
htmlPrix.innerHTML = `${totalPrix}`;
