// code de l'objet ligne panier


window.onload = function ()
{
  const bouton = document.querySelector('button.plus');
	bouton.onclick = ajoutElement;

    function ajoutElement(){
        const api_url = 'http://localhost/dernierjs/otest2.php';
        const xhr = new XMLHttpRequest() ;

        xhr.onload = function() {

             alert ( xhr.responseText );

        }
		let nom = document.getElementById("nom").textContent;
		let prix = document.getElementById("prix").textContent;
		let type = document.getElementById("type").attributes[1].value;
		let image = document.getElementById("image").attributes[1].value;
		let data = [nom,prix,type,image];

        xhr.open('POST', api_url);
        xhr.send(data);
}
}

   

 

